#!/bin/sh
#
# Copyright IBM Corp All Rights Reserved
#
# SPDX-License-Identifier: Apache-2.0
#
export PATH=$GOPATH/src/github.com/hyperledger/fabric/build/bin:${PWD}/../bin:${PWD}:$PATH
export FABRIC_CFG_PATH=${PWD}
CHANNEL_NAME=mychannel

# remove previous crypto material and config transactions
rm -fr config/*
rm -fr crypto-config/*

# generate crypto material
cryptogen generate --config=./cryptogen.yaml
if [ "$?" -ne 0 ]; then
  echo "Failed to generate crypto material..."
  exit 1
fi

# generate genesis block for orderer
configtxgen -profile ThreeOrgsOrdererGenesis -outputBlock ./channel/genesis.block
if [ "$?" -ne 0 ]; then
  echo "Failed to generate orderer genesis block..."
  exit 1
fi

# generate channel1 configuration transaction
configtxgen -profile TwoOrgsChannel1 -outputCreateChannelTx ./channel/private1.tx -channelID private1
if [ "$?" -ne 0 ]; then
  echo "Failed to generate channel1 configuration transaction..."
  exit 1
fi
# generate channel2 configuration transaction
configtxgen -profile TwoOrgsChannel2 -outputCreateChannelTx ./channel/private2.tx -channelID private2
if [ "$?" -ne 0 ]; then
  echo "Failed to generate channel2 configuration transaction..."
  exit 1
fi
# generate channel3 configuration transaction
configtxgen -profile ThreeOrgsChannel -outputCreateChannelTx ./channel/public.tx -channelID public
if [ "$?" -ne 0 ]; then
  echo "Failed to generate channel2 configuration transaction..."
  exit 1
fi
