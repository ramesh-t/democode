/*
 * Licensed to the Apache Software Foundation (ASF) under one
 * or more contributor license agreements.  See the NOTICE file
 * distributed with this work for additional information
 * regarding copyright ownership.  The ASF licenses this file
 * to you under the Apache License, Version 2.0 (the
 * "License"); you may not use this file except in compliance
 * with the License.  You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing,
 * software distributed under the License is distributed on an
 * "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
 * KIND, either express or implied.  See the License for the
 * specific language governing permissions and limitations
 * under the License.
 */

/*
 * The sample smart contract for documentation topic:
 * Writing Your First Blockchain Application
 */

package main

/* Imports
 * 4 utility libraries for formatting, handling bytes, reading and writing JSON, and string manipulation
 * 2 specific Hyperledger Fabric specific libraries for Smart Contracts
 */
import (
	"encoding/json"
	"fmt"

	"github.com/hyperledger/fabric/core/chaincode/shim"
	sc "github.com/hyperledger/fabric/protos/peer"
)

// Define the Smart Contract structure
type SmartContract struct {
}

// Define the ASN structure, with 1 propertie.  Structure tags are used by encoding/json library
type Rebate struct {
	Sender   string `json:"sender"`
	Receiver string `json:"receiver"`
	Agnumber string `json:"agnumber"`
	Timestamp string `json:"timestamp"`
	Status string `json:"status"`
	Info string `json:"info"`
	Index string `json:"index"`
}

type Claim struct {
	Claimnumber   string `json:"claimnumber"`
	Claimtype string `json:"claimtype"`
	Claimdate string `json:"claimdate"`
	Claimperiod string `json:"claimperiod"`
	Senderaddress string `json:"senderaddress"`
	Receiveraddress string `json:"receiveraddress"`
	Claimdata string `json:"claimdata"`
	Claimstatus string `json:"claimstatus"`
	Claimindex string `json:"claimindex"`
}

type Master struct {
	Contractname   string `json:"contractname"`
	Type string `json:"type"`
	Uniquenumber string `json:"unumber"`
	Saddress string `json:"saddress"`
	Raddress string `json:"raddress"`
}


/*
 * The Init method is called when the Smart Contract "fabAsn" is instantiated by the blockchain network
 * Best practice is to have any Ledger initialization in separate function -- see initLedger()
 */
func (s *SmartContract) Init(APIstub shim.ChaincodeStubInterface) sc.Response {
	return shim.Success(nil);
}

/*
 * The Invoke method is called as a result of an application request to run the Smart Contract "fabAsn"
 * The calling application program has also specified the particular smart contract function to be called, with arguments
 */
func (s *SmartContract) Invoke(APIstub shim.ChaincodeStubInterface) sc.Response {

	// Retrieve the requested Smart Contract function and arguments
	function, args := APIstub.GetFunctionAndParameters()
	// Route to the appropriate handler function to interact with the ledger appropriately
	if function == "queryRebate" {
		return s.queryRebate(APIstub, args)
	} else if function == "createRebate" {
		return s.createRebate(APIstub, args)
	} else if function == "getrebateHistory" {
		return s.getrebateHistory(APIstub, args)
	} else if function == "updateRebate" {
		return s.updateRebate(APIstub, args)
	} else if function == "ackRebate" {
		return s.ackRebate(APIstub, args)
	} else if function == "queryClaim" {
		return s.queryClaim(APIstub, args)
	} else if function == "createClaim" {
		return s.createClaim(APIstub, args)
	} else if function == "getClaimHistory" {
		return s.getClaimHistory(APIstub, args)
	} else if function == "updateClaim" {
		return s.updateClaim(APIstub, args)
	} else if function == "ackClaim" {
		return s.ackClaim(APIstub, args)
	} else if function == "createMaster" {
		return s.createMaster(APIstub, args)
	} else if function == "getMasterHistory" {
		return s.getmasterHistory(APIstub, args)
	} else if function == "queryMaster" {
		return s.queryMaster(APIstub,args)
	}
	return shim.Error("Invalid Smart Contract function name.")
}

func (s *SmartContract) queryRebate(APIstub shim.ChaincodeStubInterface, args []string) sc.Response {

	if len(args) != 1 {
		return shim.Error("Incorrect number of arguments. Expecting 1")
	}

	rebateBytes, _ := APIstub.GetState(args[0])
	return shim.Success(rebateBytes)
}

func (s *SmartContract) queryMaster(APIstub shim.ChaincodeStubInterface, args []string) sc.Response {

	if len(args) != 1 {
		return shim.Error("Incorrect number of arguments. Expecting 1")
	}

	masterBytes, _ := APIstub.GetState(args[0])
	return shim.Success(masterBytes)
}

func (s *SmartContract) createMaster(APIstub shim.ChaincodeStubInterface, args []string) sc.Response {

	if len(args) != 6 {
		return shim.Error("Incorrect number of arguments. Expecting 6")
	}

	var master = Master{Contractname: args[1],Type: args[2],Uniquenumber: args[3],Saddress: args[4],Raddress:args[5]}

	masterBytes, _ := json.Marshal(master)
	APIstub.PutState(args[0], masterBytes)

	return shim.Success(nil)
}

func (s *SmartContract) createRebate(APIstub shim.ChaincodeStubInterface, args []string) sc.Response {

	if len(args) != 8 {
		return shim.Error("Incorrect number of arguments. Expecting 8")
	}

	var rebate = Rebate{Sender: args[1],Receiver: args[2],Agnumber: args[3],Timestamp: args[4],Status: args[5],Info: args[6],Index: args[7]}

	rebateBytes, _ := json.Marshal(rebate)
	APIstub.PutState(args[0], rebateBytes)

	return shim.Success(nil)
}


func (s *SmartContract) ackRebate(APIstub shim.ChaincodeStubInterface, args []string) sc.Response {

	if len(args) != 4 {
		return shim.Error("Incorrect number of arguments. Expecting 4")
	}

	rebateBytes, _ := APIstub.GetState(args[0])
	rebate := Rebate{}

	json.Unmarshal(rebateBytes, &rebate)
	rebate.Status = args[1]
	rebate.Index=args[2]
        rebate.Timestamp=args[3]

	rebateBytes, _ = json.Marshal(rebate)
	APIstub.PutState(args[0], rebateBytes)

	return shim.Success(nil)
}

func (s *SmartContract) updateRebate(APIstub shim.ChaincodeStubInterface, args []string) sc.Response {

	if len(args) != 5 {
		return shim.Error("Incorrect number of arguments. Expecting 5")
	}

	rebateBytes, _ := APIstub.GetState(args[0])
	rebate := Rebate{}

	json.Unmarshal(rebateBytes, &rebate)
	rebate.Status = args[1]
	rebate.Index=args[2]
	rebate.Info=args[3] 
	rebate.Timestamp=args[4]

	rebateBytes, _ = json.Marshal(rebate)
	APIstub.PutState(args[0], rebateBytes)

	return shim.Success(nil)
}

func (s *SmartContract) getrebateHistory(stub shim.ChaincodeStubInterface, args []string) sc.Response {
	type AuditHistory struct {
		TxId    string   `json:"txId"`
		Value   Rebate   `json:"value"`
	}
	var history []AuditHistory;
	var rebate Rebate

	if len(args) != 1 {
		return shim.Error("Incorrect number of arguments. Expecting 1")
	}

	rebateId := args[0]
	fmt.Printf("- start getHistoryForRebate: %s\n", rebateId)

	// Get History
	resultsIterator, err := stub.GetHistoryForKey(rebateId)
	if err != nil {
		return shim.Error(err.Error())
	}
	defer resultsIterator.Close()

	for resultsIterator.HasNext() {
		historyData, err := resultsIterator.Next()
		if err != nil {
			return shim.Error(err.Error())
		}

		var tx AuditHistory
		tx.TxId = historyData.TxId                     //copy transaction id over
		json.Unmarshal(historyData.Value, &rebate)     //un stringify it aka JSON.parse()
		if historyData.Value == nil {                  //Asn has been deleted
			var emptyRebate Rebate
			tx.Value = emptyRebate               //copy nil Asn
		} else {
			json.Unmarshal(historyData.Value, &rebate) //un stringify it aka JSON.parse()
			tx.Value = rebate                      //copy Asn over
		}
		history = append(history, tx)              //add this tx to the list
	}
	fmt.Printf("- getHistoryForAsn returning:\n%s", history)

	//change to array of bytes
	historyAsBytes, _ := json.Marshal(history)     //convert to array of bytes
	return shim.Success(historyAsBytes)
}

func (s *SmartContract) getmasterHistory(stub shim.ChaincodeStubInterface, args []string) sc.Response {
	type AuditHistory struct {
		TxId    string   `json:"txId"`
		Value   Master   `json:"value"`
	}
	var history []AuditHistory;
	var masterhis Master

	if len(args) != 1 {
		return shim.Error("Incorrect number of arguments. Expecting 1")
	}

	masterId := args[0]
	fmt.Printf("- start getHistoryForRebate: %s\n", masterId)

	// Get History
	resultsIterator, err := stub.GetHistoryForKey(masterId)
	if err != nil {
		return shim.Error(err.Error())
	}
	defer resultsIterator.Close()

	for resultsIterator.HasNext() {
		historyData, err := resultsIterator.Next()
		if err != nil {
			return shim.Error(err.Error())
		}

		var tx AuditHistory
		tx.TxId = historyData.TxId                     //copy transaction id over
		json.Unmarshal(historyData.Value, &masterhis)     //un stringify it aka JSON.parse()
		if historyData.Value == nil {                  //Asn has been deleted
			var emptyMaster Master
			tx.Value = emptyMaster               //copy nil Asn
		} else {
			json.Unmarshal(historyData.Value, &masterhis) //un stringify it aka JSON.parse()
			tx.Value = masterhis                      //copy Asn over
		}
		history = append(history, tx)              //add this tx to the list
	}
	fmt.Printf("- getHistoryForAsn returning:\n%s", history)

	//change to array of bytes
	historyAsBytes, _ := json.Marshal(history)     //convert to array of bytes
	return shim.Success(historyAsBytes)
}

func (s *SmartContract) queryClaim(APIstub shim.ChaincodeStubInterface, args []string) sc.Response {
	
	if len(args) != 1 {
		return shim.Error("Incorrect number of arguments. Expecting 1")
	}
	
	claimBytesQu, _ := APIstub.GetState(args[0])
	return shim.Success(claimBytesQu)
}
	
func (s *SmartContract) createClaim(APIstub shim.ChaincodeStubInterface, args []string) sc.Response {
	
	if len(args) != 10 {
		return shim.Error("Incorrect number of arguments. Expecting 10")
	}
	
	var claim = Claim{Claimnumber: args[1],Claimtype: args[2],Claimdate: args[3],Claimperiod: args[4],Senderaddress: args[5],Receiveraddress: args[6],Claimdata: args[7],Claimstatus: args[8],Claimindex: args[9]}
	
	claimBytes, _ := json.Marshal(claim)
	APIstub.PutState(args[0], claimBytes)
	
	return shim.Success(nil)
}
	
	
func (s *SmartContract) ackClaim(APIstub shim.ChaincodeStubInterface, args []string) sc.Response {
	
	if len(args) != 3 {
		return shim.Error("Incorrect number of arguments. Expecting 3")
	}
	
	claimBytesack, _ := APIstub.GetState(args[0])
	claimAck := Claim{}
	
	json.Unmarshal(claimBytesack, &claimAck)
	claimAck.Claimstatus = args[1]
	claimAck.Claimindex = args[2]
	
	claimBytesack, _ = json.Marshal(claimAck)
	APIstub.PutState(args[0], claimBytesack)
	
	return shim.Success(nil)
}
	
func (s *SmartContract) updateClaim(APIstub shim.ChaincodeStubInterface, args []string) sc.Response {
	
	if len(args) != 4 {
		return shim.Error("Incorrect number of arguments. Expecting 4")
	}
	
	claimBytesup, _ := APIstub.GetState(args[0])
	claimup := Claim{}
	
	json.Unmarshal(claimBytesup, &claimup)
	claimup.Claimstatus = args[1]
	claimup.Claimindex=args[2]
	claimup.Claimdata=args[3] 
	
	claimBytesup, _ = json.Marshal(claimup)
	APIstub.PutState(args[0], claimBytesup)
	
	return shim.Success(nil)
}
	
	
	
func (s *SmartContract) getClaimHistory(stub shim.ChaincodeStubInterface, args []string) sc.Response {
	type AuditHistory struct {
		TxId    string   `json:"txId"`
		Value   Claim   `json:"value"`
	}
	var history []AuditHistory;
	var claimhistory Claim
	
	if len(args) != 1 {
		return shim.Error("Incorrect number of arguments. Expecting 1")
	}
	
	claimId := args[0]
	fmt.Printf("- start getHistoryForRebate: %s\n", claimId)
	
	// Get History
	resultsIterator, err := stub.GetHistoryForKey(claimId)
	if err != nil {
		return shim.Error(err.Error())
	}
	defer resultsIterator.Close()
	
	for resultsIterator.HasNext() {
		historyData, err := resultsIterator.Next()
		if err != nil {
			return shim.Error(err.Error())
		}
	
		var tx AuditHistory
		tx.TxId = historyData.TxId                     //copy transaction id over
		json.Unmarshal(historyData.Value, &claimhistory)     //un stringify it aka JSON.parse()
		if historyData.Value == nil {                  //Asn has been deleted
			var emptyClaim Claim
			tx.Value = emptyClaim               //copy nil Asn
		} else {
			json.Unmarshal(historyData.Value, &claimhistory) //un stringify it aka JSON.parse()
			tx.Value = claimhistory                      //copy Asn over
		}
		history = append(history, tx)              //add this tx to the list
	}
	fmt.Printf("- getHistoryForAsn returning:\n%s", history)
	
	//change to array of bytes
	historyAsBytes, _ := json.Marshal(history)     //convert to array of bytes
	return shim.Success(historyAsBytes)
}





// The main function is only relevant in unit test mode. Only included here for completeness.
func main() {

	// Create a new Smart Contract
	err := shim.Start(new(SmartContract))
	if err != nil {
		fmt.Printf("Error creating new Smart Contract: %s", err)
	}
}
