/*
Contract model for block chain
*/
var config = require('../../config/config.json')
var constants = require('../../config/constants.json');
var DataModel = require('./dataModel')
const sqlModel = new DataModel()
var _ = require('lodash')
var Web3 = require('web3')
const web3 = new Web3();
const request = require("request")
var uniqid = require('uniqid')
var smartContract = function(){}

smartContract.createContract = function(sender, contractData, agno, receiverAddress, stackStatus, authToken) {
  let start = new Date().getTime()
  console.log('start', start)
  let promiseArray = []
  for (let i = 0; i < receiverAddress.length; i++) {
    let chanel_url = smartContract.getContractUrl(receiverAddress[i])
    let server_url  =  config[sender].URL;
    let create_contract_url = server_url+chanel_url;
    console.log(i)
    promiseArray.push(new Promise(function (resolve, reject) {
        let date = new Date()
        let t = parseInt(date.getTime()) + parseInt(i)
        let unid = uniqid()+"-"+t
        let smartContractAddress = web3.toHex(unid)
        let strDate = date.toString()
        let reqBody = {
          "peers": ["peer0Org1","peer1Org1"],
          "fcn": "createRebate",
          "args": [smartContractAddress, sender, receiverAddress[i], agno, strDate, 'pending', contractData, "0"]
        }
          let options = {
            url: create_contract_url,
            method: "POST",
            body: reqBody,
            headers: {
                'Content-Type':'application/json;charset=utf-8',
                'Accept-Encoding': '*',
                'Authorization': authToken
            },
            json: true
          }
          request(options, function(error, contractAddress) 
          {
            if(error)
            {
              reject(error)
            }
            else
            {
                let responseArray = {
                  'receiver': receiverAddress[i],
                  'contractAddress': smartContractAddress,
                  'transactionHash': contractAddress.body
                }
                resolve(responseArray)
            }
          })
      }))
   }
  return Promise.all(promiseArray)
}

smartContract.getContractUrl = function(receiverAddress) {
  let url = config[receiverAddress].CREATE_CONTRACT_SERVICE
  return url;
}

smartContract.getAckUrl = function(receiverAddress) {
  let url = config[receiverAddress].ACK_CONTRACT_SERVICE
  return url;
}

smartContract.getUrl = function(receiverAddress) {
  let url = config[receiverAddress].GET_CONTRATCS_SERVICE
  return url;
}

smartContract.createMasterContract = function(sender, agno, receiverAddress, contracts, token, type) {
  let promiseArray = []
  for (let i = 0; i < receiverAddress.length; i++) {
    let chanel_url = smartContract.getContractUrl(receiverAddress[i])
    let server_url  =  config[sender].URL;
    let create_contract_url = server_url+chanel_url;
    new Promise(function (resolve, reject) {
        let reqBody = {
          "peer": ["peer0Org1","peer1Org1"],
          "fcn": "createMaster",
          "args": [config.MASTER_CONTRACT, contracts[i].contractAddress, type, agno, sender, receiverAddress[i]]
        }
          let options = {
            url: create_contract_url,
            method: "POST",
            body: reqBody,
            headers: {
                'Content-Type':'application/json;charset=utf-8',
                'Accept-Encoding': '*',
                'Authorization': token
            },
            json: true
          }
          request(options, function(error, contractAddress) 
          {
            if(error)
            {
              reject(error)
            }
            else
            {
                let responseArray = {
                  'receiver': receiverAddress[i],
                  'transactionHash': contractAddress.body
                }
                resolve(responseArray)
            }
          })
      })
   }
  return Promise.all(promiseArray)
}
smartContract.getSmartContractAddress = function(agNo, sender, receiverId, authToken) {
  let chanel_url = smartContract.getUrl(receiverId)
  let server_url  =  config[receiverId].URL;
  let get_master_history_url = server_url+chanel_url;
  let qbody = {
              "chaincodeName":"newchain",
              "peer": config[receiverId].peers,
              "fcn":"getMasterHistory",
              "args":[config.MASTER_CONTRACT]
            }
  let options = {
              url: get_master_history_url,
              method: "POST",
              body: qbody,
              headers: {
                  'Content-Type':'application/json;charset=utf-8',
                  'Accept-Encoding': '*',
                  'Authorization': authToken
              },
              json: true
          }
  return new Promise(function (resolve, reject) {
    request(options, function(error, result){
      if(error) {
        reject(error)
      } else {
        var masterArr= []
        result.body.forEach(function(val){
          masterArr.push(val['value'])
        })
       let contractData = masterArr.find(function(elem) {
          if(elem.unumber===agNo && elem.saddress===sender && elem.raddress===receiverId) {
            return elem.contractname
           }
        })
        resolve(contractData)
      }
    })
  })

}
smartContract.getContractData = function(contractAddress, authToken) {
  let chanel_url = smartContract.getUrl(contractAddress.raddress)
  let server_url  =  config[contractAddress.raddress].URL;
  let get_url = server_url+chanel_url;
  let reqBody = {
    "chaincodeName":"newchain",
    "peer": config[contractAddress.raddress].peers,
    "fcn":"queryRebate",
    "args":[contractAddress.contractname]
  }
  let options = {
      url: get_url,
      method: "POST",
      body: reqBody,
      headers: {
          'Content-Type':'application/json;charset=utf-8',
          'Accept-Encoding': '*',
          'Authorization': authToken
      },
      json: true
  }
  return new Promise(function (resolve, reject) {
    request(options, function(error, result) {
        if(error)
        {
          reject(error)
        }
        else
        {
          console.log("ss::",result.body)
          resolve(result.body)
        }
    })
  });
}
smartContract.acknowledgeContract = function(contractAddress, status, latestIindex, authToken) {
  let chanel_url = smartContract.getAckUrl(contractAddress.raddress)
  let server_url  =  config[contractAddress.raddress].URL;
  let ack_url = server_url+chanel_url;
   let date = new Date()
  let strDate = date.toString()
  let reqBody = {
    "peers": config[contractAddress.raddress].ackPeers,
    "fcn":"ackRebate",
    "args":[contractAddress.contractname, status, latestIindex.toString(), strDate]
   }
   console.log(reqBody)
  let options = {
    url: ack_url,
    method: "POST",
    body: reqBody,
    headers: {
        'Content-Type':'application/json;charset=utf-8',
        'Accept-Encoding': '*',
        'Authorization': authToken
    },
    json: true
  }
  return new Promise(function (resolve, reject) {
      request(options, function(error, result) {
            if(error)
            {
              console.log(error)
              reject(error)
            }
            else
            {
              console.dir(result.body)
              resolve(result.body)
            }
        })
    })
}
smartContract.accountDetails = function () {
  return Promise.resolve({})
}
smartContract.getDis1Contarcts = function(token, senderAdd) {
  let chanel_url = smartContract.getUrl(constants.DISTIBUTOR1)
  let server_url  =  config[senderAdd].URL;
  let get_master_history_url = server_url+chanel_url;
  let qbody = {
              "chaincodeName":"newchain",
              "peer": config[senderAdd].peers,
              "fcn":"getMasterHistory",
              "args":[config.MASTER_CONTRACT]
            }
  let options = {
              url: get_master_history_url,
              method: "POST",
              body: qbody,
              headers: {
                  'Content-Type':'application/json;charset=utf-8',
                  'Accept-Encoding': '*',
                  'Authorization': token
              },
              json: true
          }
  return new Promise(function (resolve, reject) {
    request(options, function(error, result){
      if(error) {
        reject(error)
      } else {
        var masterArr= []
        if(result.body!==null){
          result.body.forEach(function(val) {
            if(val['value'].type === "contract"){
              masterArr.push(val['value'])
            }
          })
        }
       resolve(masterArr)
      }
    })
  })
}
smartContract.getDis2Contarcts = function(token, senderAdd) {
  let chanel_url = smartContract.getUrl(constants.DISTIBUTOR2)
  let server_url  =  config[senderAdd].URL;
  let get_master_history_url = server_url+chanel_url;
  let qbody = {
              "chaincodeName":"newchain",
              "peer": config[senderAdd].peers,
              "fcn":"getMasterHistory",
              "args":[config.MASTER_CONTRACT]
            }
  let options = {
              url: get_master_history_url,
              method: "POST",
              body: qbody,
              headers: {
                  'Content-Type':'application/json;charset=utf-8',
                  'Accept-Encoding': '*',
                  'Authorization': token
              },
              json: true
          }
 return new Promise(function (resolve, reject) {
    request(options, function(error, result){
      if(error) {
        reject(error)
      } else {
        var masterArr= []
        if(result.body!==null){
          result.body.forEach(function(val){
            if(val['value'].type === "contract") {
              masterArr.push(val['value'])
            }
          })
        }
       resolve(masterArr)
      }
    })
  })
  
}
smartContract.getDis1Records = function(smContracts, token, senderAdd) {
  let chanel_url = smartContract.getUrl(constants.DISTIBUTOR1)
  let server_url  =  config[senderAdd].URL;
  let get_url = server_url+chanel_url;
  let promiseArray = []        
  smContracts.forEach(function(elements) {
    let qbody = {
      "chaincodeName":"newchain",
      "peer": config[senderAdd].peers,
      "fcn":"getrebateHistory",
      "args":[elements.contractname]
    }
    let options = {
          url: get_url,
          method: "POST",
          body: qbody,
          headers: {
              'Content-Type':'application/json;charset=utf-8',
              'Accept-Encoding': '*',
              'Authorization': token
          },
          json: true
      }
    promiseArray.push( new Promise(function (resolve, reject) {
      request(options, function(error, result){
        if(error) {
          reject(error)
        } else {
         resolve(result.body)
        }
      })
    }))
  })
 return Promise.all(promiseArray)
}
smartContract.getDis2Records = function(smContracts, token, senderAdd) {
  let chanel_url = smartContract.getUrl(constants.DISTIBUTOR2)
  let server_url  =  config[senderAdd].URL;
  let get_url = server_url+chanel_url;
  let promiseArray = []        
  smContracts.forEach(function(elements) {
    let qbody = {
      "chaincodeName":"newchain",
      "peer": config[senderAdd].peers,
      "fcn":"getrebateHistory",
      "args":[elements.contractname]
    }
    let options = {
          url: get_url,
          method: "POST",
          body: qbody,
          headers: {
              'Content-Type':'application/json;charset=utf-8',
              'Accept-Encoding': '*',
              'Authorization': token
          },
          json: true
      }
    promiseArray.push( new Promise(function (resolve, reject) {
      request(options, function(error, result){
        if(error) {
          reject(error)
        } else {
         resolve(result.body)
        }
      })
    }))
  })
 return Promise.all(promiseArray)
}


smartContract.getSmartContractDetails = function(contractAdd){

}
module.exports = smartContract
