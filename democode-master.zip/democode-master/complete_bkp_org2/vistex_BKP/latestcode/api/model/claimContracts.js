var config = require('../../config/config.json')
var constants = require('../../config/constants.json');
var DataModel = require('./dataModel')
const sqlModel = new DataModel()
var _ = require('lodash')
var Web3 = require('web3')
const web3 = new Web3();
const request = require("request")
var uniqid = require('uniqid')
var claimContract = function(){}

claimContract.acknowledgeClaimContract = function(contractAddress, status, latestIindex, authToken) {
    let chanel_url = claimContract.getAckUrl(contractAddress.saddress)
    let server_url  =  config[contractAddress.raddress].URL;
    let ack_url = server_url+chanel_url;
     let date = new Date()
    let strDate = date.toString()
    let reqBody = {
      "peers": config[contractAddress.raddress].ackPeers,
      "fcn":"ackClaim",
      "args":[contractAddress.contractname, status, latestIindex.toString()]
     }
    let options = {
      url: ack_url,
      method: "POST",
      body: reqBody,
      headers: {
          'Content-Type':'application/json;charset=utf-8',
          'Accept-Encoding': '*',
          'Authorization': authToken
      },
      json: true
    }
    return new Promise(function (resolve, reject) {
        request(options, function(error, result) {
              if(error)
              {
                console.log(error)
                reject(error)
              }
              else
              {
                console.dir(result.body)
                resolve(result.body)
              }
          })
      })
  }
  claimContract.accountDetails = function () {
    return Promise.resolve({})
  }
  
  claimContract.createClaimContract = function(sender, contractData, agno, receiverAddress, claimDate, claimType, claimPeriod, token){
      let start = new Date().getTime()
      let chanel_url = claimContract.getContractUrl(sender)
      let server_url  =  config[sender].URL;
      let create_contract_url = server_url+chanel_url;
      return new Promise(function (resolve, reject) {
          let date = new Date()
          let t = parseInt(date.getTime()) + parseInt(1)
          let unid = uniqid()+"-"+t
          let claimContractAddress = web3.toHex(unid)
          let strDate = date.toString()    
          let reqBody = {
            "peers": config[sender].ackPeers,
            "fcn": "createClaim",
            "args": [claimContractAddress, agno.toString(), claimType.toString(), claimDate.toString(), claimPeriod.toString(), sender, receiverAddress, contractData, 'pending', "0"]
          }
            let options = {
              url: create_contract_url,
              method: "POST",
              body: reqBody,
              headers: {
                  'Content-Type':'application/json;charset=utf-8',
                  'Accept-Encoding': '*',
                  'Authorization': token
              },
              json: true
            }
            console.log(options)
            request(options, function(error, contractAddress) 
            {
              if(error)
              {
                reject(error)
              }
              else
              {
                  let responseArray = {
                    'receiver': receiverAddress,
                    'contractAddress': claimContractAddress,
                    'transactionHash': contractAddress.body
                  }
                  resolve(responseArray)
              }
            })
        })
   }
  
  claimContract.createClaimMasterContract = function(sender, agno, receiverAddress, result, token, type){
      let chanel_url = claimContract.getContractUrl(sender)
      let server_url  =  config[sender].URL;
      let create_contract_url = server_url+chanel_url;
      return  new Promise(function (resolve, reject) {
          let reqBody = {
            "peer":  config[sender].ackPeers,
            "fcn": "createMaster",
            "args": [config.MASTER_CONTRACT, result.contractAddress, type, agno, sender, receiverAddress]
          }
            let options = {
              url: create_contract_url,
              method: "POST",
              body: reqBody,
              headers: {
                  'Content-Type':'application/json;charset=utf-8',
                  'Accept-Encoding': '*',
                  'Authorization': token
              },
              json: true
            }
            request(options, function(error, contractAddress) 
            {
              if(error)
              {
                reject(error)
              }
              else
              {
                  let responseArray = {
                    'receiver': receiverAddress,
                    'transactionHash': contractAddress.body
                  }
                  resolve(responseArray)
              }
            })
        })
  }

  claimContract.getClaimContractAddress = function(agNo, sender, receiverId, authToken) {
    let chanel_url = claimContract.getUrl(sender)
    let server_url  =  config[receiverId].URL;
    let get_master_history_url = server_url+chanel_url;
    let qbody = {
                "chaincodeName":"newchain",
                "peer": config[receiverId].peers,
                "fcn":"getMasterHistory",
                "args":[config.MASTER_CONTRACT]
              }
    let options = {
                url: get_master_history_url,
                method: "POST",
                body: qbody,
                headers: {
                    'Content-Type':'application/json;charset=utf-8',
                    'Accept-Encoding': '*',
                    'Authorization': authToken
                },
                json: true
            }
    return new Promise(function (resolve, reject) {
      request(options, function(error, result){
        if(error) {
          reject(error)
        } else {
          var masterArr= []
          result.body.forEach(function(val){
            masterArr.push(val['value'])
          })
         let contractData = masterArr.find(function(elem) {
            if(elem.unumber===agNo && elem.saddress===sender && elem.raddress===receiverId) {
              return elem.contractname
             }
          })
          resolve(contractData)
        }
      })
    })
  
  }
  
  claimContract.getClaimData = function(contractAddress, authToken) {
    let chanel_url = claimContract.getUrl(contractAddress.saddress)
    let server_url  =  config[contractAddress.raddress].URL;
    let get_url = server_url+chanel_url;
    let reqBody = {
      "chaincodeName":"newchain",
      "peer": config[contractAddress.raddress].peers,
      "fcn":"queryClaim",
      "args":[contractAddress.contractname]
    }
    let options = {
        url: get_url,
        method: "POST",
        body: reqBody,
        headers: {
            'Content-Type':'application/json;charset=utf-8',
            'Accept-Encoding': '*',
            'Authorization': authToken
        },
        json: true
    }
    return new Promise(function (resolve, reject) {
      request(options, function(error, result) {
          if(error)
          {
            reject(error)
          }
          else
          {
            console.log("ss::",result.body)
            resolve(result.body)
          }
      })
    });
  }
  claimContract.getDis1Contarcts = function(token, senderAdd) {
    let chanel_url = claimContract.getUrl(constants.DISTIBUTOR1)
    let server_url  =  config[senderAdd].URL;
    let get_master_history_url = server_url+chanel_url;
    let qbody = {
                "chaincodeName":"newchain",
                "peer": config[senderAdd].peers,
                "fcn":"getMasterHistory",
                "args":[config.MASTER_CONTRACT]
              }
    let options = {
                url: get_master_history_url,
                method: "POST",
                body: qbody,
                headers: {
                    'Content-Type':'application/json;charset=utf-8',
                    'Accept-Encoding': '*',
                    'Authorization': token
                },
                json: true
            }
    return new Promise(function (resolve, reject) {
      request(options, function(error, result){
        if(error) {
          reject(error)
        } else {
          var masterArr= []
          if(result.body!==null){
            result.body.forEach(function(val) {
              if(val['value'].type === "claim"){
                masterArr.push(val['value'])
              }
            })
          }
         resolve(masterArr)
        }
      })
    })
  }
  claimContract.getDis2Contarcts = function(token, senderAdd) {
    let chanel_url = claimContract.getUrl(constants.DISTIBUTOR2)
    let server_url  =  config[senderAdd].URL;
    let get_master_history_url = server_url+chanel_url;
    let qbody = {
                "chaincodeName":"newchain",
                "peer": config[senderAdd].peers,
                "fcn":"getMasterHistory",
                "args":[config.MASTER_CONTRACT]
              }
    let options = {
                url: get_master_history_url,
                method: "POST",
                body: qbody,
                headers: {
                    'Content-Type':'application/json;charset=utf-8',
                    'Accept-Encoding': '*',
                    'Authorization': token
                },
                json: true
            }
   return new Promise(function (resolve, reject) {
      request(options, function(error, result){
        if(error) {
          reject(error)
        } else {
          var masterArr= []
          if(result.body!==null){
            result.body.forEach(function(val){
              if(val['value'].type === "claim") {
                masterArr.push(val['value'])
              }
            })
          }
         resolve(masterArr)
        }
      })
    })
    
  }
  claimContract.getDis1Records = function(smContracts, token, senderAdd) {
    let chanel_url = claimContract.getUrl(constants.DISTIBUTOR1)
    let server_url  =  config[senderAdd].URL;
    let get_url = server_url+chanel_url;
    let promiseArray = []        
    smContracts.forEach(function(elements) {
      let qbody = {
        "chaincodeName":"newchain",
        "peer": config[senderAdd].peers,
        "fcn":"getClaimHistory",
        "args":[elements.contractname]
      }
      let options = {
            url: get_url,
            method: "POST",
            body: qbody,
            headers: {
                'Content-Type':'application/json;charset=utf-8',
                'Accept-Encoding': '*',
                'Authorization': token
            },
            json: true
        }
      promiseArray.push( new Promise(function (resolve, reject) {
        request(options, function(error, result){
          if(error) {
            reject(error)
          } else {
           resolve(result.body)
          }
        })
      }))
    })
   return Promise.all(promiseArray)
  }
  claimContract.getDis2Records = function(smContracts, token, senderAdd) {
    let chanel_url = claimContract.getUrl(constants.DISTIBUTOR2)
    let server_url  =  config[senderAdd].URL;
    let get_url = server_url+chanel_url;
    let promiseArray = []        
    smContracts.forEach(function(elements) {
      let qbody = {
        "chaincodeName":"newchain",
        "peer": config[senderAdd].peers,
        "fcn":"getClaimHistory",
        "args":[elements.contractname]
      }
      let options = {
            url: get_url,
            method: "POST",
            body: qbody,
            headers: {
                'Content-Type':'application/json;charset=utf-8',
                'Accept-Encoding': '*',
                'Authorization': token
            },
            json: true
        }
      promiseArray.push( new Promise(function (resolve, reject) {
        request(options, function(error, result){
          if(error) {
            reject(error)
          } else {
           resolve(result.body)
          }
        })
      }))
    })
   return Promise.all(promiseArray)
  }
  claimContract.getContractUrl = function(receiverAddress) {
    let url = config[receiverAddress].CREATE_CONTRACT_SERVICE
    return url;
  }
  
  claimContract.getAckUrl = function(receiverAddress) {
    let url = config[receiverAddress].ACK_CONTRACT_SERVICE
    return url;
  }
  
  claimContract.getUrl = function(receiverAddress) {
    let url = config[receiverAddress].GET_CONTRATCS_SERVICE
    return url;
  }
  module.exports = claimContract