/                  result.ReceiptLine.forEach(function(receiptLines) {
//                     let virtualSerialNumber = receiptLines['TransactionId']+date.valueOf()
//                     receiptLines['ReceiptLinesRcvTxnDFFVA'][0]['ns2:virtualSerialNumber'] = virtualSerialNumber 
//                     receiptLines['ReceiptLinesRcvTxnDFFVA'][0]['ns2:asnHash'] = contractAddress.body 
//                     receiptLines['virtualSerialNumber'] = virtualSerialNumber
//                     receiptLines['asnHash'] = contractAddress.body
//                   })
//                    let creqBody = {
//                        "peers": ["peer0.org1.example.com","peer1.org1.example.com"],
//                        "fcn": "createAsn",
//                        "args": [result.ReceiptLine[0]['virtualSerialNumber'], web3.toHex(result.ReceiptLine[0])]
//                     }
//                    let coptions = {
//                          url: requestUrl,
//                          method: "POST",
//                          body: creqBody,
//                          headers: {
//                              'Content-Type':'application/json;charset=utf-8',
//                              'Accept-Encoding': '*',
//                              'Authorization': Token
//                          },
//                          json: true
//                      }
                 /* This request for create contarct code Item level*/
//                 request(coptions, function(error, lineHash){
//                        console.log("chaild called")
//                               if(error){
//                                     console.log("error::"+error)
//                               } else {
//                                   console.log("sss::"+lineHash.body)
//                                    result.ReceiptLine.forEach(function(receiptLines) {
//                                        let virtualSerialNumber = receiptLines['TransactionId']+date.valueOf()
//                                        receiptLines['ReceiptLinesRcvTxnDFFVA'][0]['ns2:asnLineHash'] = lineHash.body 
//                                        receiptLines['asnLineHash'] = lineHash.body
//                                    }) 
//                                  result.virtualSerialNumber = virtualSerialNumber
//                                  result.asnHash =contractAddress.body
//                                  SCM.createASN(result, res)
//                                //return response.onSuccess(result, res)
//                               }
//                           });