/* Data model for sqlite */

var sqlite3 = require('sqlite3').verbose()
var path = require('path')
let basePath = path.normalize(path.join(__dirname, '/../..'))
var db = new sqlite3.Database(basePath + '/db/vistex_hyperledger.db')
var DataModel = function () {}
/* Insert latest record in sqlite */
DataModel.prototype.insert = function (agNum, sender, smartContracts, stackStatus) {
  let promiseArray = []
  smartContracts.forEach(function (iterateData) {
    let countSQL = 'SELECT COUNT(*) AS total FROM vistex_contracts WHERE Agreemrnt_Num = ? AND Sender_Address = ?  AND Receiver_Address=?'
    db.get(countSQL, [agNum, sender, iterateData.receiver], function (err, resl) {
      if (resl.total === 0) {
        let qry = 'INSERT INTO vistex_contracts(Agreemrnt_Num, Sender_Address,  Receiver_Address, Smart_Contarct_Address, Stack_Status) VALUES(?,?,?,?,?)'
        promiseArray.push(
          new Promise(function (resolve, reject) {
            db.run(qry, [agNum, sender, iterateData.receiver, iterateData.contractAddress, stackStatus],
              function (err, result) {
                if (err) {
                  reject(err)
                } else {
                  resolve(result)
                }
              })
          })
        )
      } else {
        let qry = 'UPDATE  vistex_contracts SET  status = ? WHERE  Agreemrnt_Num = ? AND Sender_Address = ?  AND Receiver_Address=?'
        promiseArray.push(
          new Promise(function (resolve, reject) {
            db.run(qry, ['pending', agNum, sender, iterateData.receiver],
              function (err, result) {
                if (err) {
                  reject(err)
                } else {
                  resolve(result)
                }
              })
          })
        )
      }
    })
  })
  return Promise.all(promiseArray)
}
/* Update status when user acknowledge the contract */
DataModel.prototype.updateStatus = function (agNum, sender, receiver) {
  let qry = 'UPDATE  vistex_contracts SET  status = ? WHERE  Agreemrnt_Num = ? AND Sender_Address = ?  AND Receiver_Address=?'
  return new Promise(function (resolve, reject) {
    db.run(qry, ['acknowledged', agNum, sender, receiver],
      function (err, result) {
        if (err) {
          reject(err)
        } else {
          resolve(result)
        }
      })
  })
}
/* Get total count of  perticular agreement number, sender&receiver address */
DataModel.prototype.getCount = function (agenum, sender, receiver) {
  let countSQL = 'SELECT COUNT(*) AS total FROM vistex_contracts WHERE Agreemrnt_Num = ? AND Sender_Address = ?  AND Receiver_Address=? '
  return new Promise(function (resolve, reject) {
    db.get(countSQL, [agenum, sender, receiver], function (err, result) {
      if (err) {
        reject(err.message)
      } else {
        resolve(result.total)
      }
    })
  })
}
DataModel.prototype.checkRecords = function (agenum, sender, receiver) {
  let countSQL = 'SELECT COUNT(*) AS total FROM vistex_contracts WHERE Agreemrnt_Num = ? AND Sender_Address = ?  AND Receiver_Address=?'
  return new Promise(function (resolve, reject) {
    db.get(countSQL, [agenum, sender, receiver], function (err, result) {
      if (err) {
        reject(err.message)
      } else {
        resolve(result.total)
      }
    })
  })
}
/* Get smart contract address */
DataModel.prototype.getSmartContractAddress = function (agenum, sender, receiver) {
  let countSQL = 'SELECT Smart_Contarct_Address FROM vistex_contracts WHERE Agreemrnt_Num = ? AND Sender_Address = ?  AND Receiver_Address=?'
  return new Promise(function (resolve, reject) {
    db.get(countSQL, [agenum, sender, receiver], function (err, result) {
      if (err) {
        reject(err.message)
      } else {
        resolve(result.Smart_Contarct_Address)
      }
    })
  })
}
/* Delete record */
DataModel.prototype.deleteRecord = function (agnum) {
  return new Promise(function (resolve, reject) {
    db.run('DELETE FROM vistex_contracts WHERE Agreemrnt_Num= ?', agnum, function (err, result) {
      if (err) {
        reject(err)
      } else {
        resolve(result)
      }
    })
  })
}

/* Get smart contart details */
DataModel.prototype.getSmartContractDetails = function (smartContractAdd) {
  let query = 'SELECT * FROM vistex_contracts WHERE Smart_Contarct_Address=?'
  return new Promise(function (resolve, reject) {
    db.all(query, [smartContractAdd], function (err, result) {
      if (err) {
        reject(err.message)
      } else {
        resolve(result)
      }
    })
  })
}
/*GET All smart contracts */
DataModel.prototype.getAllSmartContract = function (smartContractAdd) {
  let query = 'SELECT Smart_Contarct_Address FROM vistex_contracts '
  return new Promise(function (resolve, reject) {
    db.all(query, function (err, result) {
      if (err) {
        reject(err.message)
      } else {
        resolve(result)
      }
    })
  })
}
module.exports = DataModel
