/* Data contoller for block chain, sqlite */
var Validation = require('async-validation')
var contract = require('../model/contract')
var response = require('../../lib/response')
var DataModel = require('../model/dataModel')
var ERROS_MSG = require('../../config/error_msg.json').ERROS
var constants = require('../../config/constants.json')
var request = require('request-promise')
var _ = require('lodash')
var smartContractData = {}
var blockChain = function () {}
var sqlModel = new DataModel()
const tokenGen = require("../../lib/token")
blockChain.deleteRecord = function (req, res, next) {
  let agNo = req.query.agNo
  sqlModel.deleteRecord(agNo)
    .then(function (sucess) {
      return response.onSuccess({'success': 'deleted'}, res)
    })
    .catch(function (error) {
      return response.onFailure({'error': error.message}, res)
    })
}
/* Deployed new contract */
blockChain.prototype.createNewSmartContract = function(req, res, next){
  let reqObject = Object.keys(req.body).reduce((c, k) => (c[k.toLowerCase()] = req.body[k], c), {})
  let token = req.authToken
  let sender = reqObject.senderaddress
  let contractData = reqObject.contractdata
  let agno = reqObject.agreementnumber
  let receiverAddress = reqObject.receiveraddress
  var stackStatus = reqObject.stackstatus
  if (blockChain.validationtest(reqObject, res)) { return false }
  contract.createContract(sender, contractData, agno, receiverAddress, stackStatus, token)
          .then(function(result){
            contract.createMasterContract(sender, agno, receiverAddress, result, token, 'contract')
            .then(function(resp){
                     console.log(resp)
                     let responseData = {
                                      'senderAddress': reqObject.senderaddress,
                                      'receiverAddress': reqObject.receiveraddress,
                                      'agreementNumber': reqObject.agreementnumber,
                                      'smartContractAddress': result,
                                      'status': 'active',
                                      'userMessage': 'Smart Contract created successfully.',
                                      'operation': 'create'
                                    }
              return response.onSuccess(responseData, res)
            }).catch(function(error){
              return response.onFailure({'error': error.message || error}, res)
            })
          })
          .catch(function(error){
            console.log("err12", error)
            return response.onFailure({'error': error.message || error}, res)
      })
}
/* Contract activation API */
blockChain.prototype.acknowledgeContract = function (req, res, next) {
  let agNo = req.query.agreement
  let sender = req.query.senderaddress
  let receiverId = req.query.receiveraddress
  let token = req.authToken
  contract.getSmartContractAddress(agNo, sender, receiverId, token)
  .then(function(contractAddress) {
    contract.getContractData(contractAddress, token)
    .then(function(contractData) {
      let latestIindex = parseInt(contractData.index) + parseInt(1)
      if (contractData.status === "pending") {
        let status = "acknowledged"
         contract.acknowledgeContract(contractAddress, status, latestIindex, token)
         .then(function(sucessdata){
          let resObj = {
            'status': 'success',
            'contractData': contractData.info,
            'senderAddress': sender,
            'receiverAddress': receiverId,
            'agreementNumber': agNo,
            'userMessage': 'Smart Contract has been acknowledged by you.',
            'operation': 'acknowledge'
          }
          return response.onSuccess(resObj, res)
         }).catch(function(error){
          return response.onFailure({'error': error.message}, res)
         })
      } else {
        return response.onFailure({'error': ERROS_MSG.RECEVIER_ALREADY_ACTIVATED}, res)
      }
    })
    .catch(function(error){
      return response.onFailure({'error': error.message}, res)
    })

  })
  .catch(function(error) {
    return response.onFailure({'error': error.message}, res)
  })
}

/* Contract details or list of accounts API's */
blockChain.prototype.getSmartContracts = function (req, res) {
  let type = req.query.type
  if (type === 'transactions') {
    tokenGen.getToken(req, res)
    .then(function(authToken) {
       const hostn = req.hostname
       if(hostn === constants.ORG1) {
         blockChain.getManfactureRecords(authToken.authToken,constants.MANIFACTURE_ADD, type, res)
       } else if(hostn === constants.ORG2) {
        blockChain.getDist1Records(authToken.authToken, constants.DISTIBUTOR1, type, res)
       }else if(hostn === constants.ORG3) {
        blockChain.getDist2Records(authToken.authToken, constants.DISTIBUTOR2, type, res)
       } else {
         blockChain.getVistexNodeRecords(authToken.authToken,constants.VISTEX, type, res)
       }
   })
   .catch(function(error){
     return response.onFailure({'error': error.message || error}, res)
   })
  } else {
    let smartContractAdd = req.query.smartContract
    tokenGen.getToken(req, res)
    .then(function(authToken){
      contract.getDis1Contarcts(authToken.authToken, authToken.senderAdd)
      .then(function(d1contracts) {
        contract.getDis2Contarcts(authToken.authToken, authToken.senderAdd)
                .then(function(d2contracts) {
                  let mergData = d1contracts.concat(d2contracts)
                  let filterData = mergData.find(function(elem) {
                    if(elem.contractname===smartContractAdd) {
                      return elem
                     }
                  })
                  let contractDetails = {
                          agreementNumber: '', receiverAddress: '', senderAddress: ''
                        }
                        contractDetails.agreementNumber = filterData.unumber
                        contractDetails.receiverAddress = filterData.raddress
                        contractDetails.senderAddress = filterData.saddress
                        return response.onSuccess(contractDetails, res)
                })
                .catch(function(error) {
                  return response.onFailure({'error': error.message || error}, res)
                })
          })
        .catch(function(error) {
          return response.onFailure({'error': error.message || error}, res)
        })
      }).catch(function (error) {
      return response.onFailure({'error': error.message || error}, res)
    })
  }
}
/* Log report */
blockChain.prototype.viewLogs = function (req, res, next) {
  tokenGen.getToken(req, res)
   .then(function(authToken) {
      const hostn = req.hostname
      if(hostn === constants.ORG1) {
        blockChain.getManfactureRecords(authToken.authToken, constants.MANIFACTURE_ADD,'', res)
      } else if(hostn === constants.ORG2){
        blockChain.getDist1Records(authToken.authToken, constants.DISTIBUTOR1, '', res)
      }else if(hostn === constants.ORG3) {
        blockChain.getDist2Records(authToken.authToken, constants.DISTIBUTOR2, '', res)
      } else {
        blockChain.getVistexNodeRecords(authToken.authToken,constants.VISTEX, '', res)
      }
    //response.onSuccess(authToken, res)
  })
  .catch(function(error){
    return response.onFailure({'error': error.message || error}, res)
  })
}
blockChain.getManfactureRecords = function(token, senderAdd, type, res) {
  contract.getDis1Contarcts(token, senderAdd)
  .then(function(d1smcontarcts) {
  // return response.onSuccess(d1smcontarcts, res)
    contract.getDis1Records(d1smcontarcts, token, senderAdd)
    .then(function(dis1records) {
      contract.getDis2Contarcts(token, senderAdd)
      .then(function(d2smcontarcts) {
        contract.getDis2Records(d2smcontarcts, token, senderAdd)
        .then(function(dis2records) {
          let mergeData = []
          dis1records.forEach(function(d1records){
           if(d1records!==null){
              d1records.forEach(function(d1r){
                mergeData.push(d1r.value)
              })
            }
          })
          dis2records.forEach(function(d2records){
            d2records.forEach(function(d2r){
              mergeData.push(d2r.value)
            })
          })
          if(type==="transactions"){
            response.onSuccess(mergeData, res)
          }else{
            res.render('logReport', {title: 'BBIS', logData: mergeData})
          }
         
        })
        .catch(function(error) {
          return response.onFailure({'error': error.message || error}, res)
        })
      })
      .catch(function(error){
        return response.onFailure({'error': error.message || error}, res)
       })
      })
    .catch(function(error){
      return response.onFailure({'error': error.message || error}, res)
    })
  })
  .catch(function(error) {
    console.log(error)
    return response.onFailure({'error': error.message || error}, res)
  })
}

blockChain.getVistexNodeRecords = function(token, senderAdd, type, res) {
  contract.getDis1Contarcts(token, senderAdd)
  .then(function(d1smcontarcts) {
    contract.getDis1Records(d1smcontarcts, token, senderAdd)
    .then(function(dis1records) {
      contract.getDis2Contarcts(token, senderAdd)
      .then(function(d2smcontarcts) {
        contract.getDis2Records(d2smcontarcts, token, senderAdd)
        .then(function(dis2records) {
         let mergeData = []
          dis1records.forEach(function(d1records){
           if(d1records!==null){
              d1records.forEach(function(d1r){
                mergeData.push(d1r.value)
              })
            }
          })
          dis2records.forEach(function(d2records){
            d2records.forEach(function(d2r){
              mergeData.push(d2r.value)
            })
          })
          if(type==="transactions"){
            response.onSuccess(mergeData, res)
          }else{
            res.render('logReport', {title: 'BBIS', logData: mergeData})
          }
         
        })
        .catch(function(error) {
          return response.onFailure({'error': error.message || error}, res)
        })
      })
      .catch(function(error){
        return response.onFailure({'error': error.message || error}, res)
       })
      })
    .catch(function(error){
      return response.onFailure({'error': error.message || error}, res)
    })
  })
  .catch(function(error) {
    console.log(error)
    return response.onFailure({'error': error.message || error}, res)
  })
}

blockChain.getDist1Records = function(token, senderAdd, type, res) {
  contract.getDis1Contarcts(token, senderAdd)
  .then(function(d1smcontarcts) {
    contract.getDis1Records(d1smcontarcts, token, senderAdd)
    .then(function(dis1records) {
      let mergeData = []
      dis1records.forEach(function(d1records){
        if(d1records!==null){
           d1records.forEach(function(d1r){
             mergeData.push(d1r.value)
           })
         }
       })
      if(type==="transactions"){
          response.onSuccess(mergeData, res)
        } else{
        res.render('logReport', {title: 'BBIS', logData: mergeData})
        }
      })
    .catch(function(error){
      return response.onFailure({'error': error.message || error}, res)
    })
  })
  .catch(function(error) {
    console.log(error)
    return response.onFailure({'error': error.message || error}, res)
  })
}

blockChain.getDist2Records = function(token, senderAdd, type, res) {
  contract.getDis2Contarcts(token, senderAdd)
  .then(function(d2smcontarcts) {
    contract.getDis2Records(d2smcontarcts, token, senderAdd)
    .then(function(dis2records) {
      let mergeData = []
      dis2records.forEach(function(d2records){
        if(d2records!==null){
          d2records.forEach(function(d2r){
             mergeData.push(d2r.value)
           })
         }
       })
      if(type==="transactions"){
          response.onSuccess(mergeData, res)
        } else{
        res.render('logReport', {title: 'BBIS', logData: mergeData})
        }
      })
    .catch(function(error){
      return response.onFailure({'error': error.message || error}, res)
    })
  })
  .catch(function(error) {
    console.log(error)
    return response.onFailure({'error': error.message || error}, res)
  })
}

/* Basic validation for request payload */
blockChain.validationtest = function (reqObject, res) {
  smartContractData.contractdata = reqObject.contractdata
  smartContractData.senderaddress = reqObject.senderaddress
  smartContractData.receiveraddress = reqObject.receiveraddress
  smartContractData.agreementnumber = reqObject.agreementnumber
  var rule = {}
  rule.contractdata = [
    { validator: 'notEmpty', message: 'Contract Data  is missing!' }
  ]
  rule.senderaddress = [
    { validator: 'notEmpty', message: 'Sender Address is missing!' }
  ]
  rule.receiveraddress = [
    { validator: 'notEmpty', message: 'Receiver Address is missing!' }
  ]
  rule.agreementnumber = [
    { validator: 'notEmpty', message: 'Agreemnet Number is missing!' }
  ]
  var options = {trim: true}
  var errormsg = ''
  // Validate and return right error message.
  var valid = new Validation(smartContractData, rule, options)
  valid.validate(function (error) {
    if (error) {
      errormsg = true
      return response.onFailure({'errMsg': error}, res)
    }
  })
  return errormsg
}
blockChain.prototype.converions = function (req, res) {
  contract.converions()
}
module.exports = blockChain
