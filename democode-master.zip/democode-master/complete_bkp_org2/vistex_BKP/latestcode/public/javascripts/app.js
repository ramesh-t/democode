var app = angular.module('BBIS', ['ngTable','ngRoute'])
app.config(function($routeProvider) {
  $routeProvider
  .when("/api/smartcontract/viewLogs", {
      templateUrl : "../views/logRepor.ejs",
      controller:"reportController"
  })
  .when("/api/smartcontract/viewClaimLogs", {
      templateUrl : "../views/claimReport.ejs",
      controller:"claimReportController"
  })
});
app.controller('reportController', function ($scope, $http, NgTableParams) {
  $scope.convertFn = function (str) {
    return atob(str)
  }

  $scope.dateConvert = function (dateStr) {
    var date = new Date(dateStr)
    var d = date.getDate()
    var m = date.getMonth()
    m = m + 1
    var y = date.getFullYear()
    var h = date.getHours()
    var mi = date.getMinutes()
    var s = date.getSeconds()
    var fdate = y + '-' + m + '-' + d + ' ' + h + ':' + mi + ':' + s
    return fdate
  }
  $scope.refreshData = function () {
    $scope.getList()
  }
  $scope.getList = function () {
    $('#spinner').show()
    let url = document.URL
    var path = url.split('/')
    var lastIndex= path.pop();
    var apiUrl = ''
    if(lastIndex  === "viewLogs") {
      apiUrl ="/api/smartcontract/fetch?type=transactions"
    }else if(lastIndex  === "viewClaimLogs") {
      apiUrl ="/api/smartcontract/fetchClaims?type=transactions"
    }
    $http.get(apiUrl)
      .success(function (data) {
        $('#spinner').hide()
        $scope.tableParams = new NgTableParams({}, { dataset: data })
        let d = data.message
        let finalData = []
        d.forEach(function(elements){
          if(elements!==null){
            finalData.push(elements)
          }
        })
        $scope.todos = finalData
        console.log($scope.todos)
        $scope.todoF = finalData
      })
      .error(function (data) {
        console.log('Error: ' + JSON.stringify(data))
      })
  }
  $scope.getList()

  $scope.filterData = function () {
    $scope.todosFilter = []

    for (var i = 0; i < $scope.todoF.length; i++) {
      var date = new Date($scope.todoF[i].timestamp)

      var d = (date.getDate() < 10 ? '0' : '') + date.getDate()

      var m = ((date.getMonth() + 1) < 10 ? '0' : '') + (date.getMonth() + 1)

      var y = date.getFullYear()

      var h = date.getHours()

      var mi = date.getMinutes()

      var fullDate = m + '/' + d + '/' + y + ' ' + h + ':' + mi

      if (fullDate >= $scope.fromDate.split('-')[0].trim() && fullDate <= $scope.fromDate.split('-')[1].trim()) {
        $scope.todosFilter.push($scope.todoF[i])
      }
    }
    $scope.todos = ''
    $scope.todos = $scope.todosFilter
  }
})


