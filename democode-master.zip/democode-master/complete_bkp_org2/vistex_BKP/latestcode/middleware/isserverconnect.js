'user strict'
const Contract = require('../api/model/contract')
const checkConn = new Contract()
var response = require('../lib/response')
module.exports = function (req, res, next) {
  checkConn.checkConnection()
    .then(function (success) {
      next()
    })
    .catch(function (err) {
      return response.onFailure({'error': err.message || err}, res)
    })
}
