/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
const constants  = require('../config/constants.json')
const config = require("../config/config.json")
const querystring = require('querystring');
const request = require("request")
const response = require('../lib/response')
const AuthToken = function(req, res, next) {
        let requestUrl = ''
        let  orgName = ''
        let ORG1= constants.ORG1[0].toUpperCase() + constants['ORG1'].slice(1)
        let ORG2= constants.ORG2[0].toUpperCase() + constants['ORG2'].slice(1)
        let ORG3= constants.ORG3[0].toUpperCase() + constants['ORG3'].slice(1)
        let ORG4= constants.ORG4[0].toUpperCase() + constants['ORG4'].slice(1)
        let senderAdd =''
        const hostn =req.hostname
	
        if(hostn === constants.ORG1 || hostn === ORG1) {
         if(req.query.agreement) {
            requestUrl = config[req.query.receiveraddress].URL+config.TOKEN_GEN_URL
            orgName = config[req.query.receiveraddress].organization
        } else {
            let reqObject = Object.keys(req.body).reduce((c, k) => (c[k.toLowerCase()] = req.body[k], c), {})
            requestUrl = config[reqObject.senderaddress].URL+config.TOKEN_GEN_URL
            orgName = config[reqObject.senderaddress].organization
        }
        } else if(hostn === constants.ORG2 || hostn === ORG2){
            if(req.query.agreement) {
                requestUrl = config[req.query.receiveraddress].URL+config.TOKEN_GEN_URL
                orgName = config[req.query.receiveraddress].organization
            } else {
                let reqObject = Object.keys(req.body).reduce((c, k) => (c[k.toLowerCase()] = req.body[k], c), {})
                requestUrl = config[reqObject.senderaddress].URL+config.TOKEN_GEN_URL
                orgName = config[reqObject.senderaddress].organization
            }
        }else if(hostn === constants.ORG3 || hostn === ORG3) {
            if(req.query.agreement) {
                requestUrl = config[req.query.receiveraddress].URL+config.TOKEN_GEN_URL
                orgName = config[req.query.receiveraddress].organization
            } else {
                let reqObject = Object.keys(req.body).reduce((c, k) => (c[k.toLowerCase()] = req.body[k], c), {})
                requestUrl = config[reqObject.senderaddress].URL+config.TOKEN_GEN_URL
                orgName = config[reqObject.senderaddress].organization
            }
        }else{
            if(req.query.agreement) {
                requestUrl = config[req.query.receiveraddress].URL+config.TOKEN_GEN_URL
                orgName = config[req.query.receiveraddress].organization
            } else {
                let reqObject = Object.keys(req.body).reduce((c, k) => (c[k.toLowerCase()] = req.body[k], c), {})
                requestUrl = config[reqObject.senderaddress].URL+config.TOKEN_GEN_URL
                orgName = config[reqObject.senderaddress].organization
            }
        }
        let reqBody  = {
            "username":"Jim",
            "orgName": orgName
        }
console.log(requestUrl)
        var formData = querystring.stringify(reqBody);
        let options = {
                        url: requestUrl,
                        method: "POST",
                        body: formData,
                        headers: {
                            'Content-Type' : 'application/x-www-form-urlencoded',
                            'Accept-Encoding': '*',
                        }
                }
                request(options, function (err, respon, body) {
                        if(err){
                            console.log("err", err)
                            return response.onFailure(err , res, 500);
                        }else{
                            let resp = JSON.parse(body)
                            let tkn = "Bearer " +resp.token
                            req.authToken = tkn
                            next()
                        }
              });
        
}
module.exports = AuthToken