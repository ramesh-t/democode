var express = require('express')
var BlockChain = require('../api/services/blockChain')
var ClaimService = require('../api/services/claimService')
var authToken = require('../middleware/authToken')
var router = express.Router()
const blocks = new BlockChain()
const claims = new ClaimService()
router.post('/create',  authToken, blocks.createNewSmartContract)
router.get('/fetch',  blocks.getSmartContracts)
router.get('/activate', authToken, blocks.acknowledgeContract)
router.get('/viewLogs',  blocks.viewLogs)
router.post('/sigin',  authToken, blocks.createNewSmartContract)

router.post('/createClaim', authToken, claims.createClaimContract)
router.get('/activateClaimContract', authToken, claims.acknowledgeClaimContract)
router.get('/viewClaimLogs',  claims.viewLogs)
router.get('/fetchClaims',  claims.getSmartContracts)

module.exports = router
