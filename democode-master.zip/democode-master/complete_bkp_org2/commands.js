
//Private Channel Commands
//18.191.60.106

//User Register
curl -s -X POST http://localhost:4000/users -H "content-type: application/x-www-form-urlencoded" -d 'username=Jim&orgName=Org1'


//Create Cannel
curl -s -X POST \
  http://localhost:4000/channels \
  -H "authorization: Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJleHAiOjE1MzI2Mjc5MTMsInVzZXJuYW1lIjoiSmltIiwib3JnTmFtZSI6Ik9yZzEiLCJpYXQiOjE1MzI1OTE5MTN9.1W_oSv6_3SiiKXqFAfT02-AUw98I6j6JwURCl7NpFXU" \
  -H "content-type: application/json" \
  -d '{
	"channelName":"private1",
	"channelConfigPath":"../artifacts/channel/private1.tx"
}'

//Add Peers to Channel
curl -s -X POST \
  http://localhost:4000/channels/private1/peers \
  -H "authorization: Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJleHAiOjE1MzI2Mjc5MTMsInVzZXJuYW1lIjoiSmltIiwib3JnTmFtZSI6Ik9yZzEiLCJpYXQiOjE1MzI1OTE5MTN9.1W_oSv6_3SiiKXqFAfT02-AUw98I6j6JwURCl7NpFXU" \
  -H "content-type: application/json" \
  -d '{
	"peers": ["peer0Org1","peer1Org1"]
}'

//Install Chain code on Private Channel
curl -s -X POST \
  http://localhost:4000/chaincodes \
  -H "authorization: Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJleHAiOjE1MzI2Mjc5MTMsInVzZXJuYW1lIjoiSmltIiwib3JnTmFtZSI6Ik9yZzEiLCJpYXQiOjE1MzI1OTE5MTN9.1W_oSv6_3SiiKXqFAfT02-AUw98I6j6JwURCl7NpFXU" \
  -H "content-type: application/json" \
  -d '{
	"peers": ["peer0Org1","peer1Org1"],
	"chaincodeName":"rate",
	"chaincodePath":"github.com/private/go",
	"chaincodeType": "golang",
	"chaincodeVersion":"v0"
}'

// Instantiate chain code
curl -s -X POST \
  http://localhost:4000/channels/private1/chaincodes \
  -H "authorization: Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJleHAiOjE1MzI2Mjc5MTMsInVzZXJuYW1lIjoiSmltIiwib3JnTmFtZSI6Ik9yZzEiLCJpYXQiOjE1MzI1OTE5MTN9.1W_oSv6_3SiiKXqFAfT02-AUw98I6j6JwURCl7NpFXU" \
  -H "content-type: application/json" \
  -d '{
	"peers": ["peer0Org1","peer1Org1"],
	"chaincodeName":"rate",
	"chaincodeVersion":"v0",
  "channelName":"public",
	"chaincodeType": "golang",
	"args":[""]
}'

// Invoke Chain Code createRate
curl -s -X POST \
  http://localhost:4000/channels/private1/chaincodes/rate \
  -H "authorization: Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJleHAiOjE1MzI2Mjc5MTMsInVzZXJuYW1lIjoiSmltIiwib3JnTmFtZSI6Ik9yZzEiLCJpYXQiOjE1MzI1OTE5MTN9.1W_oSv6_3SiiKXqFAfT02-AUw98I6j6JwURCl7NpFXU" \
  -H "content-type: application/json" \
  -d '{
	"peers": ["peer0Org1","peer1Org1"],
	"fcn":"createRate",
	"args":["001","CarBusiness","5Lakhs"]
}'

//Oracle
curl -X POST \
 http://localhost:5100/bcsgw/rest/v1/transaction/invocation \
-H "Content-type:application/json" \
-d ' {
  "channel": "innoprivate",
  "chaincode": "private",
  "chaincodeVer": "1.0",
  "method": "createRate",
  "args": ["001","CarBusiness","3L"],
  "proposalWaitTime": 50000,
  "transactionWaitTime": 60000
}'



//Query ChainCode
curl -s -X POST \
  http://localhost:4000/channels/private1 \
  -H "authorization: Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJleHAiOjE1MzI2Mjc5MTMsInVzZXJuYW1lIjoiSmltIiwib3JnTmFtZSI6Ik9yZzEiLCJpYXQiOjE1MzI1OTE5MTN9.1W_oSv6_3SiiKXqFAfT02-AUw98I6j6JwURCl7NpFXU" \
  -H "content-type: application/json" \
  -d '{
  "chaincodeName":"rate",
	"peer": "peer0Org1",
	"fcn":"queryRate",
	"args":["001"]
}'


---------------------------------------  Private Channel Completed   ---------------

3b0c8d6be331522e2a25a070421ac0b815865f416f1f295eb2b7e96344084c2f


//Create Cannel
curl -s -X POST \
  http://localhost:4000/channels \
  -H "authorization: Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJleHAiOjE1MzI2Mjc5MTMsInVzZXJuYW1lIjoiSmltIiwib3JnTmFtZSI6Ik9yZzEiLCJpYXQiOjE1MzI1OTE5MTN9.1W_oSv6_3SiiKXqFAfT02-AUw98I6j6JwURCl7NpFXU" \
  -H "content-type: application/json" \
  -d '{
	"channelName":"channel2",
	"channelConfigPath":"../artifacts/channel/channel2.tx"
}'

//Add Peers to Channel
curl -s -X POST \
  http://localhost:4000/channels/channel2/peers \
  -H "authorization: Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJleHAiOjE1MzI2Mjc5MTMsInVzZXJuYW1lIjoiSmltIiwib3JnTmFtZSI6Ik9yZzEiLCJpYXQiOjE1MzI1OTE5MTN9.1W_oSv6_3SiiKXqFAfT02-AUw98I6j6JwURCl7NpFXU" \
  -H "content-type: application/json" \
  -d '{
	"peers": ["peer0.org1.example.com","peer1.org1.example.com"]
}'

//Install Chain code on Public Channel
curl -s -X POST \
  http://localhost:4000/chaincodes \
  -H "authorization: Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJleHAiOjE1MzI2Mjc5MTMsInVzZXJuYW1lIjoiSmltIiwib3JnTmFtZSI6Ik9yZzEiLCJpYXQiOjE1MzI1OTE5MTN9.1W_oSv6_3SiiKXqFAfT02-AUw98I6j6JwURCl7NpFXU" \
  -H "content-type: application/json" \
  -d '{
	"peers": ["peer0.org1.example.com","peer1.org1.example.com"],
	"chaincodeName":"general1",
	"chaincodePath":"github.com/public/go",
	"chaincodeType": "golang",
	"chaincodeVersion":"v0"
}'

// Instantiate chain code
curl -s -X POST \
  http://localhost:4000/channels/channel2/chaincodes \
  -H "authorization: Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJleHAiOjE1MzI2Mjc5MTMsInVzZXJuYW1lIjoiSmltIiwib3JnTmFtZSI6Ik9yZzEiLCJpYXQiOjE1MzI1OTE5MTN9.1W_oSv6_3SiiKXqFAfT02-AUw98I6j6JwURCl7NpFXU" \
  -H "content-type: application/json" \
  -d '{
	"peers": ["peer0.org1.example.com","peer1.org1.example.com"],
	"chaincodeName":"general1",
	"chaincodeVersion":"v0",
  "channelName":"channel2",
	"chaincodeType": "golang",
	"args":["check"]
}'

// Invoke Chain Code createRate
curl -s -X POST \
  http://localhost:4000/channels/channel2/chaincodes/general1 \
  -H "authorization: Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJleHAiOjE1MzI2Mjc5MTMsInVzZXJuYW1lIjoiSmltIiwib3JnTmFtZSI6Ik9yZzEiLCJpYXQiOjE1MzI1OTE5MTN9.1W_oSv6_3SiiKXqFAfT02-AUw98I6j6JwURCl7NpFXU" \
  -H "content-type: application/json" \
  -d '{
	"peers": ["peer0.org1.example.com","peer1.org1.example.com"],
	"fcn":"createItem",
	"args":["BC001ITEM0011","4545425452"]
}'

//Query ChainCode
curl -s -X POST \
  http://localhost:4000/channels/channel2 \
  -H "authorization: Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJleHAiOjE1MzI2Mjc5MTMsInVzZXJuYW1lIjoiSmltIiwib3JnTmFtZSI6Ik9yZzEiLCJpYXQiOjE1MzI1OTE5MTN9.1W_oSv6_3SiiKXqFAfT02-AUw98I6j6JwURCl7NpFXU" \
  -H "content-type: application/json" \
  -d '{
  "chaincodeName":"general1",
	"peer": "peer0.org1.example.com",
	"fcn":"queryItem",
	"args":["BC001ITEM0011"]
}'

curl -s -X POST \
  http://localhost:4000/channels/channel2 \
  -H "authorization: Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJleHAiOjE1MzI2Mjc5MTMsInVzZXJuYW1lIjoiSmltIiwib3JnTmFtZSI6Ik9yZzEiLCJpYXQiOjE1MzI1OTE5MTN9.1W_oSv6_3SiiKXqFAfT02-AUw98I6j6JwURCl7NpFXU" \
  -H "content-type: application/json" \
  -d '{
  "chaincodeName":"general1",
	"peer": "peer0.org1.example.com",
	"fcn":"getasnHistory",
	"args":["BC001ITEM0011"]
}'


curl -s -X GET http://18.191.60.106:4000/channels/channel2/transactions/d7a4fc63725a92e9e321df8ffb36de673b8d66636579e5cbafa36c4ef2637820?peer=peer0.org1.example.com \
  -H "authorization: Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJleHAiOjE1MzIwMTQ3NzksInVzZXJuYW1lIjoiSmltIiwib3JnTmFtZSI6Ik9yZzEiLCJpYXQiOjE1MzE5Nzg3Nzl9.AI87SvKAboKoJEG4I3zO-_YR9uEDj3lFmmTTIBuH2-4" \
  -H "content-type: application/json"


  curl -s -X GET \
  "http://localhost:4000/channels/private/blocks/1?peer=peer0.org1.example.com" \
  -H "authorization: Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJleHAiOjE1Mjg4MjI5MjUsInVzZXJuYW1lIjoiSmltIiwib3JnTmFtZSI6Ik9yZzEiLCJpYXQiOjE1Mjg3ODY5MjV9.bzlxN1fLv8i_7hvkBtzCb8odo99RZmT3v5QKAdNZ4cc" \
  -H "content-type: application/json"

  curl -s -X GET \
  "http://localhost:4000/channels?peer=peer0.org1.example.com" \
  -H "authorization: Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJleHAiOjE1Mjg4MjI5MjUsInVzZXJuYW1lIjoiSmltIiwib3JnTmFtZSI6Ik9yZzEiLCJpYXQiOjE1Mjg3ODY5MjV9.bzlxN1fLv8i_7hvkBtzCb8odo99RZmT3v5QKAdNZ4cc" \
  -H "content-type: application/json"

  curl -s -X GET \
  "http://localhost:4000/channels/private?peer=peer0.org1.example.com" \
  -H "authorization: Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJleHAiOjE1Mjg4MjI5MjUsInVzZXJuYW1lIjoiSmltIiwib3JnTmFtZSI6Ik9yZzEiLCJpYXQiOjE1Mjg3ODY5MjV9.bzlxN1fLv8i_7hvkBtzCb8odo99RZmT3v5QKAdNZ4cc" \
  -H "content-type: application/json"
